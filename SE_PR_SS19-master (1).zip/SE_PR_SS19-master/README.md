# SE_PR_SS19_Fitnessmanager

ZIELE DES PRAKTIKUMS:
Planung und Aufwandsabschätzung
Anforderungsdefinition, Design, Implementierung, Qualitätssicherung
Verwendung von Software Engineering Werkzeugen (Repositories, Bug Tracking, Planung, Zeiterfassung)
Reporting
Dokumentation der Ergebnisse (Systemdokumentation, Testdokumentation)

Fitnessmanager

Erstellen von Workouts. 
1. Ein Workout besteht aus einer Liste von Übungen (Exercises)
2. Angabe der Wiederholungen oder der Dauer zu einer Übung
3. Durchführen von Workouts: Workout starten und Übungen abhaken
4. Zuordnungen von Übungen zu Workout aus Katalog von Übungen
5. Planung von Workouts in Kalendern
6. Analysen wie z.B. durchgeführte Workouts bzw. Übungen über einen bestimmten Zeitraum
7. Excel export/import
